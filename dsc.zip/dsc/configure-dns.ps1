Configuration DnsTest {
    # Import the module that contains the resources we're using.
    Import-DscResource -ModuleName PsDesiredStateConfiguration

    # The Node statement specifies which targets this configuration will be applied to.
    Node 'localhost' {

       File DscFile {
           Type = "Directory"
           Ensure = "Present"
           DestinationPath = "C:\Scripts"
       }

       # The first resource block ensures that the DNS Server feature is enabled.
        WindowsFeature DNS {
            Ensure = "Present"
            Name =  "DNS Server"
        }

    }
} 